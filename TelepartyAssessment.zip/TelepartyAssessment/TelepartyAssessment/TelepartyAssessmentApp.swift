//
//  TelepartyAssessmentApp.swift
//  TelepartyAssessment
//
//  Created by ModiJi on 11/01/26.
//

import SwiftUI

@main
struct TelepartyAssessmentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(worker: MetadataService())
        }
    }
}
