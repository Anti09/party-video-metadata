//
//  PlayerService.swift
//  TelepartyAssessment
//
//  Created by ModiJi on 11/01/26.
//

import Foundation

protocol MetadataServiceWorker: AnyObject {
    func fetchVideoMetadata(videoId: String) async throws -> PlayerResponse
}

final class MetadataService: MetadataServiceWorker {

    func fetchVideoMetadata(videoId: String) async throws -> PlayerResponse {

        guard let url = StringConstants.ytURL.toURL else {
            throw NetworkError.invalidURL
        }

        let body = PlayerRequestBody(
            context: .init(
                client: .init(
                    clientName: StringConstants.clientName,
                    clientVersion: StringConstants.clientVersion
                )
            ),
            videoId: videoId
        )

        let jsonData = try JSONEncoder().encode(body)

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = jsonData
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("https://www.youtube.com", forHTTPHeaderField: "Origin")

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse,
              200..<300 ~= httpResponse.statusCode else {
            throw NetworkError.invalidResponse
        }
        return try JSONDecoder().decode(PlayerResponse.self, from: data)
    }
}

enum NetworkError: Error {
    case invalidURL
    case invalidResponse
}
