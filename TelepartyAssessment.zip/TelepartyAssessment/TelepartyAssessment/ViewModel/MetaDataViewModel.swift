//
//  MetaDataViewModel.swift
//  TelepartyAssessment
//
//  Created by ModiJi on 11/01/26.
//

import Observation
import Foundation

@Observable
final class MetaDataViewModel {

    private let metaDataWorker: MetadataServiceWorker
    var videoDetail: VideoDetails?
    var isError: Bool = false

    init(metaDataWorker: MetadataServiceWorker) {
        self.metaDataWorker = metaDataWorker
    }

    func fetchMetaData() async {
        do {
            let response = try await metaDataWorker.fetchVideoMetadata(
                videoId: StringConstants.videoID
            )
            videoDetail = response.videoDetails
        } catch {
            print("Error:", error)
            isError = true
        }
    }
}

