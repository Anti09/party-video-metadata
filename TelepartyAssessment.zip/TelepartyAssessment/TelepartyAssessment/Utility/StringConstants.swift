//
//  StringConstants.swift
//  TelepartyAssessment
//
//  Created by ModiJi on 11/01/26.
//

import Foundation
import UIKit

final class StringConstants {

    /// Client
    static let clientName: String = "WEB"
    static let clientVersion: String = "2.20240101.00.00"

    /// Video
    static let videoID: String = "KSEiQBDHy7A"
    static let ytURL: String = "https://www.youtube.com/youtubei/v1/player"

    /// String
    static let loadingText = "Loading metadata…"
    static let somethingWentWrong = "Something went wrong"
    static let author = "Author"
    static let duration = "Duration"
}

extension String {
    var toURL: URL? {
        URL(string: self)
    }
}

extension URL {
    var isValidUrl: Bool {
        UIApplication.shared.canOpenURL(self)
    }
}

extension Double {
    var toMinutesString: String {
        let minutes = self / 60.0
        return String(format: "%.1f", minutes)
    }
}
