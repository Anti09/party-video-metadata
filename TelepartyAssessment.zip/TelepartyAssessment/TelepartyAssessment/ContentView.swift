//
//  ContentView.swift
//  TelepartyAssessment
//
//  Created by ModiJi on 11/01/26.
//

import SwiftUI

import SwiftUI

struct ContentView: View {

    @State private var viewModel: MetaDataViewModel

    init(worker: MetadataServiceWorker) {
        _viewModel = State(
            initialValue: MetaDataViewModel(metaDataWorker: worker)
        )
    }

    var body: some View {
        VStack(spacing: 16) {
            if let video = viewModel.videoDetail {
                HStack(spacing: 12) {

                    AsyncImage(url: video.getThumbnail()) { phase in
                        switch phase {
                        case .empty:
                            ProgressView()
                        case .success(let image):
                            image
                                .resizable()
                                .scaledToFill()
                        case .failure:
                            Image(systemName: "exclamationmark.triangle.fill")
                                .resizable()
                                .scaledToFit()
                        @unknown default:
                            EmptyView()
                        }
                    }
                    .frame(width: 150, height: 90)
                    .clipped()
                    .cornerRadius(8)

                    VStack(alignment: .leading, spacing: 8) {
                        Text(video.title ?? "")
                            .font(.caption.bold())
                            .lineLimit(2)

                        Text("\(StringConstants.author): \(video.author ?? "")")
                            .foregroundColor(.red)

                        Text("\(StringConstants.duration): \(video.getMinute()) min")
                            .foregroundColor(.red)
                    }
                    .font(.caption2.bold())
                }
                .padding(12)
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color(.systemBackground))
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Color.gray.opacity(0.25), lineWidth: 1)
                )
                .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)

            } else {
                ProgressView(viewModel.isError ? StringConstants.somethingWentWrong : StringConstants.loadingText)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(8)
        .task {
            await viewModel.fetchMetaData()
        }
    }
}


#Preview {
    ContentView(worker: MetadataService())
}
