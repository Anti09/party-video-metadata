//
//  PlayerRequestBody.swift
//  TelepartyAssessment
//
//  Created by ModiJi on 11/01/26.
//


import Foundation


struct PlayerRequestBody: Encodable {
    let context: Context?
    let videoId: String?

    struct Context: Encodable {
        let client: Client?
    }

    struct Client: Encodable {
        let clientName, clientVersion: String?
    }
}

struct PlayerResponse: Decodable {
    let videoDetails: VideoDetails?
}

struct VideoDetails: Decodable {
    let videoId, title, lengthSeconds, shortDescription, author: String?
    let thumbnail: Thumbnail?

    func getMinute() -> String {
        Double(lengthSeconds ?? "0.0")?.toMinutesString ?? ""
    }


    func getThumbnail() -> URL? {
        thumbnail?.thumbnails?.first?.url?.toURL
    }
}

struct Thumbnail: Codable {
    let thumbnails: [ThumbnailElement]?
}

struct ThumbnailElement: Codable {
    let url: String?
    let width, height: Int?
}
